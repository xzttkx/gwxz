const btn = document.getElementById('btn');
const result = document.getElementById('result');

// 添加一个全局变量 used，记录已经使用过的用户
let used = [];

btn.addEventListener('click', () => {
    // 获取当前用户的 IP 地址
    const ip = getIP();

    // 判断当前用户是否已经抽过奖
    if (used.indexOf(ip) !== -1) {
        result.innerHTML = '您已经抽过奖了，请勿重复参加！';
        return;
    }

    // 如果当前用户没有抽过奖，则进行抽奖操作
    const random = Math.random();
    if (random < 0.1) {
        result.innerHTML = '恭喜您获得特等奖，请添加小志微信：l2007886z领取奖励！';
    } else if (random < 0.3) {
        result.innerHTML = '恭喜您获得一等奖，请添加小志微信：l2007886z领取奖励！';
    } else if (random < 0.6) {
        result.innerHTML = '恭喜您获得二等奖，请添加小志微信：l2007886z领取奖励！';
    } else {
        result.innerHTML = '很遗憾，您没有中奖。';
    }

    // 将当前用户的 IP 地址添加到 used 数组中
    used.push(ip);
});

// 获取用户 IP 地址的函数
function getIP() {
    var RTCPeerConnection = window.RTCPeerConnection || window.mozRTCPeerConnection || window.webkitRTCPeerConnection; //compatibility for firefox and chrome
    var pc = new RTCPeerConnection({
        iceServers: []
    });
    var noop = function () {};
    pc.createDataChannel(""); //create a bogus data channel
    pc.createOffer(pc.setLocalDescription.bind(pc), noop); // create offer and set local description
    pc.onicecandidate = function (ice) { //listen for candidate events
        if (!ice || !ice.candidate || !ice.candidate.candidate) return;
        pc.onicecandidate = noop;
        return ice.candidate.candidate.split(' ')[4];
    };
}
